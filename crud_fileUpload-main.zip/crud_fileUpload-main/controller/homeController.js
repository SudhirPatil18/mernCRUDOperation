const express = require('express');
const Product = require('../model/productModel')
const path = require('path');
const flash = require('connect-flash');
const session = require('express-session');

//index page controller.
exports.index = (req, res) => {
    Product.find((err, data) => {
        if (!err) {
            res.render('index', {
                title: "index page",
                message: req.flash('message'),
                viewdata: data
            })
        }
    })
}

//register page controller.
exports.register = (req, res) => {
    res.render('register', {
        title: "register page",
        error: req.flash('error'),
        data: "register data"
    })
}

//store the data.
exports.store = (req, res) => {
    const image = req.file
    const Products = new Product({
        id: req.body.id,
        name: req.body.name,
        email: req.body.email,
        mobile_no: req.body.mobile_no,
        image: image.path,
        status: 1
    })
    Products.save().then((result) => {
        console.log(result, "added successfully");
        req.flash('message', 'Product added successfully.')
        res.redirect('/');
    }).catch((err) => {
        console.log(err, "add failed");
        req.flash('error', 'You cannot send blank data');
        res.redirect('/add-product')
    })
}

//edit page controller.
exports.edit = (req, res) => {
    const product_id = req.params.u_id
    Product.findById(product_id).then(result => {
        console.log(result);
        res.render('edit', {
            viewdata: result
        })
    }).catch(err => {
        console.log(err);
    })
}

//update page controller.
exports.update = (req, res, next) => {
    const { uid: product_id, id, name, email, mobile_no } = req.body;
    const image = req.file;

    console.log('Request body:', req.body);

    if (!product_id || !id || !name || !email || !mobile_no || !image) {
        console.log('Missing required fields');
        return res.status(400).send('All fields are required');
    }

    Product.findById(product_id).then((result) => {
        if (!result) {
            console.log('Product not found');
            return res.status(404).send('Product not found');
        }

        result.id = id;
        result.name = name;
        result.email = email;
        result.mobile_no = mobile_no;
        result.image = image.path;

        return result.save().then(() => {
            console.log(result, "Data Updated");
            res.redirect('/');
        }).catch(err => {
            console.error('Error saving product:', err);
            res.status(500).send('Update Failed');
        });
    }).catch(err => {
        console.error('Error finding product:', err);
        res.status(500).send('Update Failed');
    });
}



//delete the data.
exports.delete = (req, res) => {
    const productId = req.params.u_id
    Product.deleteOne({ _id: productId }).then(deletedata => {
        console.log(deletedata, "delete successful");
        res.redirect('/');
    }).catch(err => {
        console.log((err, "delete failed"));
    })
}